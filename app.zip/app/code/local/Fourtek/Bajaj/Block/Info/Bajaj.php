<?php
// app/code/local/Envato/Custompaymentmethod/Block/Info/Custompaymentmethod.php
class Fourtek_Bajaj_Block_Info_Bajaj extends Mage_Payment_Block_Info
{
  protected function _prepareSpecificInformation($transport = null)
  {
     if (null !== $this->_paymentSpecificInformation) {
               return $this->_paymentSpecificInformation;
           }
           $info = $this->getInfo();
           $transport = new Varien_Object();
           
           $transport->addData(array(
               Mage::helper('payment')->__('Bank Transfer Type') => $info->getBankTransferType(),
               Mage::helper('payment')->__('Bank Transfer Amount') => $info->getBankTransferAmount(),
               Mage::helper('payment')->__('Bank Transfer Date') => $info->getBankTransferDate(),
               Mage::helper('payment')->__('Bank Transfer Detail') => $info->getBankTransferDetail()
           ));
       
       $transport = parent::_prepareSpecificInformation($transport);
           return $transport;
  }
}