<?php
 
class Fourtek_Bajaj_Model_Paymentmethod extends Mage_Payment_Model_Method_Abstract {
  protected $_code  = 'bajaj';
  protected $_formBlockType = 'bajaj/form_bajaj';
  protected $_infoBlockType = 'bajaj/info_bajaj';
 
  
  public function isAvailable($quote = null){
    if(!$quote){
      return false;
    }
    
    if($quote->getAllVisibleItems() <= 2){
      return false;
    }
    
    return true;
  }
  
  
    public function validate(){
       parent::validate();
     
     
       $info = $this->getInfoInstance();

       $no = $info->getCheckNo();
       $date = $info->getCheckDate();
       return $this;
   }
 
  public function getOrderPlaceRedirectUrl()
  {
    return Mage::getUrl('bajaj/payment/redirect', array('_secure' => false));
  }
}